Store this plan in `context/changes/deployment/deployment-plan.md`
