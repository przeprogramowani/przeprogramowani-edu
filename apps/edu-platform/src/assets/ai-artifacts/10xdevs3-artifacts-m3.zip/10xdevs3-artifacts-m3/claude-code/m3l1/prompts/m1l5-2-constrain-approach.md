I want to ensure that auto-deploy on the main branch is handled by {{platform_name}} and not any external CI/CD system.
