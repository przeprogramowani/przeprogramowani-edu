Please extend plan with prerequisites - how to configure CLI for {{platform_name + extra tooling}}
